import { faker } from '@faker-js/faker';

export class Company {
  companyName: string;
  catchPhrase: string;
  address: [number, number];

  constructor() {
    this.companyName = faker.company.name();
    this.catchPhrase = faker.company.catchPhrase();
    // this.address = [
    //   parseFloat(faker.address.latitude()),
    //   parseFloat(faker.address.longitude()),
    // ];

    this.address = [13.23, 34.44];
  }

  markerContent(): string {
    return `
    <div>
      <h1>company Name:${this.companyName}</h1>
      <h3>Catch Phrase:${this.catchPhrase}</h3>
    </div>
    `;
  }
}
