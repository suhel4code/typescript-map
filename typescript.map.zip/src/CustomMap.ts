import * as L from 'leaflet';

export interface Mappable {
  address: [number, number];
  markerContent(): string;
}

export class CustomMap {
  private map: L.Map;

  constructor(divId: string, address: Mappable) {
    this.map = L.map(divId).setView(address.address, 10);
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution:
        '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>',
    }).addTo(this.map);
  }

  addMarker(address: Mappable) {
    const marker = L.marker(address.address).addTo(this.map);
    marker.bindPopup(address.markerContent());
  }
}
