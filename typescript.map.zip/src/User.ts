import { faker } from '@faker-js/faker';

export class User {
  name: string;
  address: [number, number];

  constructor() {
    this.name = faker.name.firstName();
    // this.address = [
    //   parseFloat(faker.address.latitude()),
    //   parseFloat(faker.address.longitude()),
    // ];
    this.address = [13.25, 34.49];
  }

  markerContent(): string {
    return `Name:${this.name}`;
  }
}
