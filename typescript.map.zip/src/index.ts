import { User } from './User';
import { Company } from './Company';
// import * as L from 'leaflet';

import { CustomMap } from './CustomMap';

const user = new User();
const company = new Company();

const map = new CustomMap('map', user);

const userMarker = map.addMarker(user);
const companyMarker = map.addMarker(company);
